import mysql, { Connection } from "mysql2";

const dbConnection: Connection = mysql.createConnection({
  user: "lilohrco_root",
  host: "localhost",
  password: "pasaloph.com",
  database: "lilohrco_demo",
});

dbConnection.connect((err) => {
  if (err) {
    console.error("Error", err);
    return;
  }

  console.log("Connected to MySQL");
});

export default dbConnection;
